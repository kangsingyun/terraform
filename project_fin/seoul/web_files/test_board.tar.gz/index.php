<?php
	require_once(__DIR__.'/config.php');
?>
<html>

<head>

	<meta charset="utf-8">

	<title><?=htmlspecialchars($site_title, ENT_QUOTES, 'UTF-8')?></title>

	<link rel="stylesheet" href="style.css">

</head>

<body>

	<header class="site-header">

		<div class="site-header__inner">

			<h1 class="site-title">Test Board</h1>

			<p class="site-description">A simple PHP board</p>

		</div>

	</header>

	<main class="page">

		<section class="content-panel">

<?php

	session_start();

	$con = db_connect();

	$list_size = 10;

	$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

	if($page < 1)

		$page = 1;

	$count_result = mysqli_query($con, "select count(*) as total from board");

	$count_row = mysqli_fetch_array($count_result);

	$total_count = (int)$count_row['total'];

	$total_pages = max(1, ceil($total_count / $list_size));

	if($page > $total_pages)

		$page = $total_pages;

	$offset = ($page - 1) * $list_size;

	if(!isset($_SESSION['username'])){

?>

	<form class="login-bar" action="login.php" method="post">

		<label>Username <input type="text" name="username" size="10" required/></label>

		<label>Password <input type="password" name="password" size="10" required/></label>

		<input type="submit" name="login" value="Login"/>

	</form>

<?php

	}

	else{

		echo "<div class='toolbar'><span class='welcome'>Welcome ".$_SESSION['username']."</span><div class='actions'>";

?>




	<input type="button" value="Logout" onclick="location.href='login.php'">

	<input type="button" value="Write" onclick="location.href='write.php'">

<?php

		echo "</div></div>";

	}

?>

	<table class="board-table">

	<thead>

		<tr>

			<th class="col-number">number</th>

			<th>title</th>

			<th class="col-name">name</th>

			<th class="col-date">date</th>

		</tr>

	</thead>

	<tbody>

<?php

	$result = mysqli_query($con, "select * from board order by id desc limit ".$offset.", ".$list_size);

	while($row = mysqli_fetch_array($result)){

?>

	<tr>

		<td class="col-number"><?=$row['id']?></td>

		<td>

			<a href="view.php?id=<?=$row['id']?>">

				<?=$row['title']?>

			</a>

		</td>

		<td class="col-name"><?=$row['user']?></td>

		<td class="col-date"><?=date("Y-m-d H:i", strtotime($row['date']))?></td>

	</tr>

<?php

	}

?>

	</tbody>

	</table>

<?php

	if($total_pages > 1){

?>

	<nav class="pagination" aria-label="Board pagination">

<?php

		if($page > 1){

?>

		<a href="index.php?page=<?=$page - 1?>">&laquo; Previous</a>

<?php

		}

		for($i = 1; $i <= $total_pages; $i++){

			if($i == $page){

?>

		<span class="current"><?=$i?></span>

<?php

			}

			else{

?>

		<a href="index.php?page=<?=$i?>"><?=$i?></a>

<?php

			}

		}

		if($page < $total_pages){

?>

		<a href="index.php?page=<?=$page + 1?>">Next &raquo;</a>

<?php

		}

?>

	</nav>

<?php

	}

?>

		</section>

	</main>

</body>

</html>
