<?php

	require_once("./file.php");
	require_once(__DIR__.'/config.php');




	if(!isset($_GET["id"])){

		echo "<script>alert('Invalid access page');</script>";

		echo "<meta http-equiv='refresh' content='0; url=index.php'>";

	}




	$id=$_GET['id'];

	$con=db_connect();

	$result=mysqli_query($con,"SELECT * FROM board WHERE id=".$id);

	if(mysqli_num_rows($result)==0){

		echo "<script>alert('Invalid access page');</script>";

		echo "<meta http-equiv='refresh' content='0; url=index.php'>";

	}

	$row = mysqli_fetch_array($result)

?>

<html>

<head>

	<meta charset="utf-8">

	<title><?=htmlspecialchars($site_title, ENT_QUOTES, 'UTF-8')?></title>

	<link rel="stylesheet" href="style.css">

</head>

<body>

	<header class="site-header">

		<div class="site-header__inner">

			<h1 class="site-title">Test Board</h1>

			<p class="site-description">A simple PHP board</p>

		</div>

	</header>

	<main class="page">

		<section class="content-panel">

	<table class="detail-table">

	<tr>

		<th>subject</th>

		<td><?=$row['title']?></td>

	</tr>

	<tr>

		<th>name</th>

		<td><?=$row['user']?></td>

	</tr>

	<tr>

		<th>date</th>

		<td><?=date("Y-m-d H:i:s", strtotime($row['date']))?></td>

	</tr>

	<tr>

		<th>content</th>

		<td><div class="post-content"><?=render_post_content($row['comment'])?></div></td>

	</tr>

	<tr>

		<th>attachment</th>

			<td>

			<?php

				if($row['file'])

					echo "<a href='./download.php?file=$row[file]'>".substr(strstr($row['file'],'@'),1)."</a>";

				else

					echo "<span class='empty-file'>No attachment</span>";

	?>		</td>

	</tr>

	</table>

	<div class="actions">

		<input type="button" value="Back" onclick="location.href='index.php'">

	</div>

		</section>

	</main>

</body>

</html>
