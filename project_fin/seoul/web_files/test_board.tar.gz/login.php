<?php
	require_once(__DIR__.'/config.php');
?>
<html>

<head>

	<meta charset="utf-8">

	<title><?=htmlspecialchars($site_title, ENT_QUOTES, 'UTF-8')?></title>

	<link rel="stylesheet" href="style.css">

</head>

<body>

<?php

	if(isset($_POST['login']))

	{

		$username = $_POST['username'];

		$password = $_POST['password'];

		$con = db_connect();

		$result = mysqli_query($con, "select * from users where username='$username' and password='$password'");

		if(mysqli_num_rows($result) == 0)

			echo "<script>alert('Invalid username or password');</script>";

		else{

			session_start();

			$_SESSION['username']=$username;

		}

	}

	else{

		session_start();

		session_destroy();

	}

?>

<meta http-equiv='refresh' content='0; url=index.php'>
