<?php

	require_once("./file.php");
	require_once(__DIR__.'/config.php');

	session_start();




	if(isset($_POST['write'])){

		$username=$_POST['username'];

		$title=$_POST['title'];

		$comment=$_POST['comment'];

		$date=date("Y-m-d H:i:s");

		$file="";




		if(is_uploaded_file($_FILES['upfile']['tmp_name']))

			$file=file_upload($_FILES['upfile']);




		$con=db_connect();

		$stmt = mysqli_prepare($con, "INSERT INTO board(`user`, `title`, `comment`, `file`, `date`) VALUES (?, ?, ?, ?, ?)");
		$result = false;

		if($stmt){
			mysqli_stmt_bind_param($stmt, 'sssss', $username, $title, $comment, $file, $date);
			$result = mysqli_stmt_execute($stmt);
			mysqli_stmt_close($stmt);
		}

		if(!$result){

			echo "<script>alert('fail save comment');history.back();</script>";
			exit;
		}

?>




<meta http-equiv='refresh' content='0; url=index.php'>




<?php

}

else{

?>


<html>

<head>

	<meta charset="utf-8">

	<title><?=htmlspecialchars($site_title, ENT_QUOTES, 'UTF-8')?></title>

	<link rel="stylesheet" href="style.css">

</head>

<body>

	<header class="site-header">

		<div class="site-header__inner">

			<h1 class="site-title">Test Board</h1>

			<p class="site-description">A simple PHP board</p>

		</div>

	</header>

	<main class="page">

		<section class="content-panel">



	<form action="" method="post" enctype="multipart/form-data">

		<table class="form-table">

			<tr>

				<th>subject</th>

				<td><input type="text" name="title" required/></td>

			</tr>

			<tr>

				<th>name</th>

<?php

	echo "<td><input type='text' name='username' value=".$_SESSION['username']." readonly/></td>"

?>




			</tr>

			<tr>

				<th>content</th>

				<td><textarea cols="30" rows="8" name="comment" required></textarea></td>

			</tr>

			<tr>

				<th>attachment</th>

				<td><input type="file" name="upfile"></td>

			</tr>

		</table>

		<div class="actions">

		<input type="submit" name="write" value="save"/>

		<input type="reset" value="reset"/>

		<input type="button" value="back" onclick="location.href='index.php'">

		</div>

	</form>

		</section>

	</main>

</body>

</html>

<?php

}

?>
